This plugin is based on the core enrolment cohort.
Within this plugin we add a course greeting to the plugin similar to the self enrol plugin.

You can receive a copy of the GNU General Public License
at <http:www.gnu.org/licenses/>.

Installation:
To install elediacohortgreeting just copy the folder "elediacohortgreeting" into your moodle/enrol/elediacohortgreeting.
After that you have to go to http://your-moodle/admin (Site administration -> Notifications) to trigger the installation process.

Using:
The greeting text can be configured in each enrol instance of this plugin.
So you can have multiple instances with differnent greetings for differnent groups in each course.
